import UIKit

func greet1(person: String, day: String) -> String { // com label
    return "Olá \(person), hoje é \(day)."
}
greet1(person: "Paula", day: "Quarta-feira")

func greet2(_ person: String, on day: String) -> String { // sem e com label
    return "Olá \(person), hoje é \(day)."
}
greet2("Paula", on: "Quinta")

func greet3(_ person: String, _ day: String) -> String { // sem label
    return "Olá \(person), hoje é \(day)."
}
greet3("Paula", "Sexta")

// função com tupla para retornar vários valores
func calculaEstatistica(scores: [Int]) -> (min: Int, max: Int, sum: Int) {
    var min = scores[0]
    var max = scores[0]
    var sum = 0
    
    for score in scores {
        if score > max {
            max = score
        } else if score < min {
            min = score
        }
        sum += score
    }
    
    return (min, max, sum)
}

let estatisticas = calculaEstatistica(scores: [5, 3, 100, 3, 9])
print(estatisticas)
print(estatisticas.sum)
print(estatisticas.1) // segundo item do retorno

// funções aninhadas ou alinhadas - função dentro de função
func returnFifteen() -> Int {
    var y = 10
    
    func add(){
        y += 5
    }
    add()
    
    return y
}

returnFifteen()

// funções de primeira classe - pode retornar outra função
func makeIncrementer() -> ((Int) -> Int) {
    func addOne(number: Int) -> Int {
        return 1 + number
    }
    
    return addOne
}

var increment = makeIncrementer()
increment(7)

// função que recebe outra função como argumento
func hasAnyMatches(list: [Int], condition: (Int) -> Bool) -> Bool {
    for item in list {
        if condition(item) {
            return true
        }
    }
    return false
}

func lessThenTen(number: Int) -> Bool {
    return number < 10
}

var numbers = [20, 19, 40, 12]
hasAnyMatches(list: numbers, condition: lessThenTen)

// Closures - Blocos de códigos chamados posteriormente - HOF em JS
var numbers2 = [20, 19, 7, 12]
numbers2.map({ (number: Int) -> Int in
    let result = 3 * number
    return result
})

let mappedNumbers = numbers2.map({number in 3 * number})

let sortedNumbers = numbers2.sorted { $0 > $1 }
print(sortedNumbers)
