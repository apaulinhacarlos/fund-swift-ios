import UIKit

// Concorrencias - app executa mais de uma tarefa ao mesmo tempo, simultaneamente
// Mais de uma thread em execução
// GCD (Grand Central Dispatch) e Async/Await

// GCD
let startTime = CFAbsoluteTimeGetCurrent()
DispatchQueue.global().sync {
    for i in 0...3 {
        print("Fui... \(i)")
    }
}
DispatchQueue.global().sync {
    for i in 0...3 {
        print("Voltei... \(i)")
    }
}

//DispatchQueue.main().sync {
//    // Executando na main thread (thread principal)
//}

// ---

// Async/Await
func fetchUserId(from server: String) async -> Int {
    if server == "primary" {
        return 97
    }
    return 501
}

func fetchUsername(from server: String) async -> String {
    let userId = await fetchUserId(from: server)
    if userId == 501 {
        return "João Souza"
    }
    return "Convidado"
}

func connectUser(to server: String) async {
    async let userId = fetchUserId(from: server)
    async let username = fetchUsername(from: server)
    let greeting = await "Olá \(username), user Id \(userId)"
    print(greeting)
}

Task {
    await connectUser(to: "primary")
}

// --

let gallery = [
    "Summer Vaction": ["praia.png", "campo.png", "shopping.png"],
    "Road Trip": ["paris.png", "roma.png"]
]

func listPhotos(inGallery name: String) async -> [String] {
    // Simulação de rede assíncrono
    do {
        try await Task.sleep(until: .now + .seconds(2), clock: .continuous)
    } catch {}
    return gallery[name] ?? []
}

Task {
    let photoNames = await listPhotos(inGallery: "Summer Vaction")
    let sortedNames = photoNames.sorted()
    let name = sortedNames[0]
}

// Sincrono
func add(_ photo: String, toGallery: String) {
    print("Adicionando a foto \(photo) na galeria \(toGallery)")
}

func remove(_ photo: String, fromGallery: String) {
    print("Removendo a foto \(photo) na galeria \(fromGallery)")
}

Task {
    let firstPhoto = await listPhotos(inGallery: "Summer Vaction")[0]
    add(firstPhoto, toGallery: "Road Trip")
    // neste ponto firtsPhoto está temporariamente em ambas galerias
    remove(firstPhoto, fromGallery: "Summer Vaction")
}

func move(_ photoName: String, from source: String, to destination: String) {
    add(photoName, toGallery: destination)
    remove(photoName, fromGallery: source)
}


Task {
    let firstPhoto = await listPhotos(inGallery: "Summer Vaction")[0]
    move(firstPhoto, from: "Summer Vaction", to: "Road Trip")
    print("Sucesso")
}

// Assincrono
Task {
    let handle = FileHandle.standardInput
    for try await line in handle.bytes.lines {
        print(line)
    }
}

func downloadPhoto(named: String) async -> String {
    // Simula chamada ao back-end
    do {
        try await Task.sleep(until: .now + .seconds(2), clock: .continuous)
    } catch {}
    return named
}

Task {
    let photoNames = await listPhotos(inGallery: "Summer Vaction")
    
    async let firstPhoto = downloadPhoto(named: photoNames[0])
    async let secondPhoto = downloadPhoto(named: photoNames[1])
    async let thirdPhoto = downloadPhoto(named: photoNames[2])
    
    let photos = await [firstPhoto, secondPhoto, thirdPhoto]
    print(photos)
}

// Simultanedade estruturada
Task {
    await withTaskGroup(of: String.self) {
        taskGroup in
            let photoNames = await listPhotos(inGallery: "Summer Vaction")
            for name in photoNames {
                taskGroup.addTask { await downloadPhoto(named: name)}
            }
        }
}

// Simultanedade não estruturada
Task {
    let photo = await listPhotos(inGallery: "Summer Vaction")[0]
    let handle = Task {
        return await downloadPhoto(named: photo)
    }
//    handle.cancel()
    let result = await handle.value
}

// Atores
actor Temperatura {
    let label: String
    var meas: [Int]
    private(set) var max: Int

    init(label: String, meas: Int) {
        self.label = label
        self.meas = [meas]
        self.max = meas
    }
}

Task {
    let logger = Temperatura(label: "ar livre", meas: 25)
    print(await logger.max)
}

extension Temperatura {
    func update(with mea: Int) {
        meas.append(mea)
        if mea > max {
            max = mea
        }
    }
}

//Task {
//    let logger = Temperatura.update(with: 35)
//    print(await logger.max)
//}

// Dominio de simultaniedade
struct TemperaturaLeitura: Sendable {
    var mea: Int
}

extension Temperatura {
    func addLeitura(from reading: TemperaturaLeitura) {
        meas.append(reading.mea)
    }
}

Task {
    let logger = Temperatura(label: "chaleira", meas: 45)
    let leitura = TemperaturaLeitura(mea: 85)
    await logger.addLeitura(from: leitura)
    print(await logger.max)
}

